/* Set INDI Library version */
#define INDI_VERSION 2.1.6

/* Define INDI Data Dir */
#define DATA_INSTALL_DIR "/usr/share/indi/"
